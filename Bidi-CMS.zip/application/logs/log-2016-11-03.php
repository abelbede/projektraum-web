<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-03 23:22:50 --> 404 Page Not Found: Article/3
ERROR - 2016-11-03 23:22:58 --> 404 Page Not Found: Article/6
ERROR - 2016-11-03 23:28:23 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-03 23:28:35 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-03 23:30:58 --> 404 Page Not Found: admin/Faviconico/index
