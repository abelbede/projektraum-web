<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-07 23:00:39 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-07 23:00:50 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-07 23:01:35 --> 404 Page Not Found: admin/Faviconico/index
