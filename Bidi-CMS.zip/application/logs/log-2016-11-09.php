<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-09 00:22:00 --> 404 Page Not Found: User/login
ERROR - 2016-11-09 00:22:09 --> 404 Page Not Found: Page/user
ERROR - 2016-11-09 00:22:27 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-09 00:22:35 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-09 00:22:38 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-09 00:23:04 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-09 00:23:13 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-09 22:49:16 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-09 22:49:59 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
