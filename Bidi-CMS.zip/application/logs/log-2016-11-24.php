<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-24 16:19:46 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-24 19:22:04 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 43
ERROR - 2016-11-24 19:22:04 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 43
ERROR - 2016-11-24 19:22:09 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:22:09 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:29 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:29 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:32 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:32 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:48 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:48 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:49 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:25:49 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:26:14 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:26:14 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:26:44 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:26:44 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:27:25 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:27:25 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:30:31 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\cms\application\controllers\Page.php 63
ERROR - 2016-11-24 19:30:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cms\application\helpers\cms_helper.php 56
ERROR - 2016-11-24 19:31:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cms\application\helpers\cms_helper.php 56
ERROR - 2016-11-24 19:31:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cms\application\helpers\cms_helper.php 56
ERROR - 2016-11-24 19:33:36 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 61
ERROR - 2016-11-24 19:33:36 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 61
ERROR - 2016-11-24 19:39:30 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 61
ERROR - 2016-11-24 19:39:30 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\cms\application\controllers\Page.php 61
ERROR - 2016-11-24 19:40:37 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:40:37 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:40:39 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:40:39 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\cms\application\controllers\Page.php 60
ERROR - 2016-11-24 19:41:33 --> Severity: Notice --> Undefined variable: recent_news C:\xampp\htdocs\cms\application\views\sidebar.php 2
ERROR - 2016-11-24 19:41:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cms\application\helpers\cms_helper.php 56
ERROR - 2016-11-24 19:41:58 --> Severity: Notice --> Undefined variable: recent_news C:\xampp\htdocs\cms\application\views\sidebar.php 2
ERROR - 2016-11-24 19:41:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cms\application\helpers\cms_helper.php 56
ERROR - 2016-11-24 19:42:35 --> Severity: Notice --> Undefined variable: recent_news C:\xampp\htdocs\cms\application\views\sidebar.php 2
ERROR - 2016-11-24 19:42:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\cms\application\helpers\cms_helper.php 56
ERROR - 2016-11-24 19:45:27 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 44
ERROR - 2016-11-24 19:45:27 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 44
ERROR - 2016-11-24 19:48:50 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 44
ERROR - 2016-11-24 19:48:50 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 44
ERROR - 2016-11-24 19:53:22 --> Severity: Notice --> Undefined property: Article::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Article.php 17
ERROR - 2016-11-24 19:53:22 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Article.php 17
ERROR - 2016-11-24 19:53:38 --> Severity: Notice --> Undefined property: Article::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Article.php 17
ERROR - 2016-11-24 19:53:38 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Article.php 17
ERROR - 2016-11-24 19:55:17 --> Severity: Notice --> Undefined property: Article::$aritcle_m C:\xampp\htdocs\cms\application\libraries\Frontend_Controller.php 10
ERROR - 2016-11-24 19:55:17 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\libraries\Frontend_Controller.php 10
ERROR - 2016-11-24 19:55:49 --> Severity: Notice --> Undefined property: Article::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Article.php 17
ERROR - 2016-11-24 19:55:49 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Article.php 17
ERROR - 2016-11-24 19:56:05 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-24 19:56:27 --> Severity: Notice --> Undefined property: Page::$aritcle_m C:\xampp\htdocs\cms\application\controllers\Page.php 44
ERROR - 2016-11-24 19:56:27 --> Severity: Error --> Call to a member function get_recent() on null C:\xampp\htdocs\cms\application\controllers\Page.php 44
ERROR - 2016-11-24 20:58:40 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\cms\application\helpers\cms_helper.php 5
ERROR - 2016-11-24 20:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\helpers\cms_helper.php 5
ERROR - 2016-11-24 20:59:27 --> Severity: Notice --> Undefined index: meta_title C:\xampp\htdocs\cms\application\helpers\cms_helper.php 5
