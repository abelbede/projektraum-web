<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Description of test
 *
 * @author Berthold
 */
class test extends CI_Controller {

    function __construct() {
        parent::__construct();
         $this->load->model('page_m');        
    }

    function index() {
       $pages = $this->page_m->get_by(array('title' => 'about'));
         $pages = $this->page_m->get();
          var_dump($pages);
    }
    public function save(){
        $data = array(
            'title' => 'My page',
            'slug' => 'my-page',
            'order' => '2',
            'body' => 'This is some Text!'
        );
        $id = $this->page_m->save($data);
        var_dump($id);
    }
    public function update(){
        $data = array(            
            'order' => '3'            
        );
        $id = $this->page_m->save($data, 3);
        var_dump($id);
    }
    
    public function delete() {
                
        //$pages = $this->page_m->get_by(array('title' => 'about'));
         $id = $this->page_m->delete(3);
       
    }

}

?>
