<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Description of article_m
 *
 * @author Berthold
 */
class Article_m extends MY_Model {

    protected $_table_name = 'articles';      
    protected $_order_by = 'pubdate desc, id desc';   
    protected $_timestamps = TRUE;
    public $rules = array(
        'pubdate' => array('field' => 'pubdate', 'label' => 'Publication date', 'rules' => 'trim|required|exact_length[10]'),
        'title' => array('field' => 'title', 'label' => 'Title', 'rules' => 'required|max_length[100]'),
        'slug' => array('field' => 'slug', 'label' => 'Slug', 'rules' => 'trim|required|min_length[1]|max_length[100]|url_title'),     
        'body' => array('field' => 'body', 'label' => 'Body', 'rules' => 'trim|required')
    );
    
    function __construct() {
        parent::__construct();
    }

    public function get_new() {
        $article = new stdClass();
        $article->title = '';
        $article->pubdate = date('Y-m-d');
        $article->slug = '';      
        $article->body = '';
        return $article;       
    }
    
    public function set_published( ) {     
        $this->db->where('pubdate <= ', date('Y-m-d'));
    }
    
    public function get_recent($limit = 3) {          
          $limit = (int) $limit;
          $this->set_published();
          $this->db->limit($limit);
          return parent::get();
          }
}

