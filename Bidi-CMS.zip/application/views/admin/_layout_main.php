<?php $this->load->view('admin/components/page_head'); ?>
  <body>

    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <a class="navbar-brand" href="<?php echo site_url('') ?>" target="_blank"><?php echo $meta_title ?></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">     
            <li class="active"><a href="<?php echo site_url('/admin/dashboard') ?>">Dashboard</a></li>
            <li><?php echo anchor('admin/page', 'Pages'); ?></li>
            <li><?php echo anchor('admin/page/order', 'Order pages'); ?></li>
             <li><?php echo anchor('admin/article', 'News articles'); ?></li>
            <li><?php echo anchor('admin/user', 'Users'); ?></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container">
        <div class="row">
            <!--Main column-->
                  <div class="col-md-9">
                      <section>
                          <?php $this->load->view($subview); ?>  
                      </section>              
                  </div>
            <!--Sidebar-->
            <div class="col-md-3">
                 <section>
                          <?php echo mailto('berthold.abel@gmail.com', '<i class="glyphicon glyphicon-envelope"></i> berthold.abel@gmail.com'); ?><br>
                          <?php echo anchor('admin/user/logout', '<i class="glyphicon glyphicon-off"></i> logout'); ?>
                      </section>    

            </div>
    </div>
</div><!-- /.container -->
<?php $this->load->view('admin/components/page_tale'); ?>
