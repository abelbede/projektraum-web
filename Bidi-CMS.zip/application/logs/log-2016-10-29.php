<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-29 21:49:38 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/dummy
ERROR - 2016-10-29 21:59:15 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/dummy
ERROR - 2016-10-29 21:59:35 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/dummy
