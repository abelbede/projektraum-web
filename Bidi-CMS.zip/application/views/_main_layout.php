<?php $this->load->view('components/page_head'); ?>
<body>
<div class="container">
    <section>
        <h1><?php echo anchor('', strtoupper(config_item('site_name'))) ?></h1>
    </section>
 <nav class="navbar navbar-inverse">
  <div class="container-fluid">   
     <?php echo get_menu($menu) ?>
  </div>
</nav>    
</div>        
    <div class="container" style="border-bottom-style: solid">
<div class="row">
<?php $this->load->view('templates/'.$subview); ?>
</div>    
</div>            
<?php $this->load->view('components/page_tail'); ?>