<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-31 21:41:18 --> Severity: Notice --> Undefined variable: config_item C:\xampp\htdocs\cms\application\views\_main_layout.php 5
ERROR - 2016-10-31 21:41:18 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\cms\application\views\_main_layout.php 5
ERROR - 2016-10-31 22:42:30 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-10-31 22:42:44 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-10-31 22:42:57 --> 404 Page Not Found: admin/Faviconico/index
