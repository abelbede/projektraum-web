<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\controllers\Article.php 30
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 30
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\controllers\Article.php 30
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 30
ERROR - 2016-11-21 00:25:14 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:25:14 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 4
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 5
ERROR - 2016-11-21 00:25:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 6
ERROR - 2016-11-21 00:25:23 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:25:23 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:25:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:25:23 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 4
ERROR - 2016-11-21 00:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 5
ERROR - 2016-11-21 00:25:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 6
ERROR - 2016-11-21 00:26:09 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:26:09 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:26:09 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:26:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:26:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 4
ERROR - 2016-11-21 00:26:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 5
ERROR - 2016-11-21 00:26:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 6
ERROR - 2016-11-21 00:29:00 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:29:00 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:29:00 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:29:33 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:29:33 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:29:33 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:30:17 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:30:17 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:30:17 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:30:20 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:30:20 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:30:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:30:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:31:37 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:31:37 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:31:37 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:31:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:31:46 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:31:46 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:31:46 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:33:00 --> Severity: Warning --> Missing argument 1 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:33:00 --> Severity: Warning --> Missing argument 2 for Article::index() C:\xampp\htdocs\cms\application\controllers\Article.php 19
ERROR - 2016-11-21 00:33:00 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-21 00:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-21 00:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 4
ERROR - 2016-11-21 00:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 5
ERROR - 2016-11-21 00:33:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\views\templates\article.php 6
ERROR - 2016-11-21 00:33:09 --> Severity: Notice --> Use of undefined constant admin - assumed 'admin' C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:09 --> Severity: Notice --> Use of undefined constant user - assumed 'user' C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:09 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:09 --> Severity: Notice --> Use of undefined constant login - assumed 'login' C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:09 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:14 --> Severity: Notice --> Use of undefined constant admin - assumed 'admin' C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:14 --> Severity: Notice --> Use of undefined constant user - assumed 'user' C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:14 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:14 --> Severity: Notice --> Use of undefined constant login - assumed 'login' C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:33:14 --> Severity: Warning --> Division by zero C:\xampp\htdocs\cms\application\libraries\Admin_Controller.php 20
ERROR - 2016-11-21 00:36:22 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-21 08:21:27 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
