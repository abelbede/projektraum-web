<!--    Main Content-->
    <div class="col-md-9" >       
        
            <h2><?php echo e($article->title); ?></h2>
            <p class="pubdate"><?php echo e($article->pubdate); ?></p>
            <?php echo $article->body; ?>
         
    </div>
<!--    Sidebar-->
    <div class="col-md-3 sidebar" style="border-left-style:  groove;">
        <h2> Recent News</h2>              
        <?php $this->load->view('sidebar') ?>   
    </div>