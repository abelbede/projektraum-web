<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title><?php echo $meta_title ?></title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url('/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
    <!-- Datepicker:   http://www.eyecon.ro/bootstrap-datepicker/ -->
    <link href="<?php echo base_url('/datepicker/css/datepicker.css') ?>" rel="stylesheet">
     <!-- Custom styles for nestedSortables -->
    <link href="<?php echo base_url('/css/admin.css') ?>" rel="stylesheet">  
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('/bootstrap/css/starter-template.css') ?>" rel="stylesheet">
       
    <!--    jQuery for Drag and Drop Page-Elements -->
     <script src="<?php echo base_url('/js/jquery-ui/jquery-3.1.1.min.js') ?>"></script>
    <?php if(isset($sortable) && $sortable === TRUE){ ?>
     <script src="<?php echo base_url('/js/jquery-ui/jquery-ui.min.js') ?>"></script>
    <script src="<?php echo base_url('/js/nestedSortable/jquery.mjs.nestedSortable.js') ?>"></script>
    <?php }; ?>
    <script src="<?php echo base_url('/js/tinymce/tinymce.min.js') ?>"></script>
    <script src="<?php echo base_url('/js/tinymce/jquery.tinymce.min.js') ?>"></script>
    <script>
        tinymce.init({
            selector: '#mytextarea',  // change this value according to your html 
        });
     </script>
       <!-- Datepicker:   http://www.eyecon.ro/bootstrap-datepicker/ -->
     <script src="<?php echo base_url('/datepicker/js/bootstrap-datepicker.js') ?>"></script>
  </head>
