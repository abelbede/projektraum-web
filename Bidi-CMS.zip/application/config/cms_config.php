<?php
$config['site_name'] = 'Bidi-Web';