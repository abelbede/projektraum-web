<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-19 09:12:18 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-19 09:12:41 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-19 09:13:09 --> 404 Page Not Found: admin/Faviconico/index
