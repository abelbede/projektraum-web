<!DOCTYPE html>
<html lang="de">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title><?php echo $meta_title; ?></title>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="<?php echo base_url('/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">        
  <link href="<?php echo base_url('/css/styles.css') ?>" rel="stylesheet">        
   <script src="<?php echo base_url('/js/jquery-ui/jquery-3.1.1.min.js') ?>"></script>
  <script src="<?php echo base_url('/bootstrap/js/bootstrap.min.js') ?>"></script>
  

   
  </head>
