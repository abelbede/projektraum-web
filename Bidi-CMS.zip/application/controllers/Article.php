<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

/**
 * Description of Article
 *
 * @author Berthold
 */
class Article extends Frontend_Controller {

    function __construct() {
        parent::__construct();
       
    }

    function index($id,$slug) {
        //fetch the article
        $this->article_m->set_published();
        $this->data['article'] = $this->article_m->get($id);        
        //return 404 if not found
        count($this->data['article'] || show_404(uri_string()));
        //redirect if slug was incorrect
        $requested_slug = $this->uri->segment(3);
        $set_slug = $this->data['article']->slug;
        if($requested_slug !=  $set_slug){
            redirect('article/'.$this->data['article']->id.'/'.$this->data['article']->slug, 'locator', '301');
        }
        //load view
         add_meta_title($this->data['article']->title);
        $this->data['subview'] = 'article';       
        $this->load->view('_main_layout',$this->data);
    }

}

?>
