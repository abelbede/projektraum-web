<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-04 00:03:04 --> 404 Page Not Found: Article/4
