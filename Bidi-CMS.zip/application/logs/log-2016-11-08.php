<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-08 17:58:32 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
ERROR - 2016-11-08 17:58:56 --> 404 Page Not Found: admin/Faviconico/index
ERROR - 2016-11-08 17:59:17 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/favicon.ico
