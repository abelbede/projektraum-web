<?php
$config['full_tag_open'] = '<p>';
$config['full_tag_close'] = '</p>';
$config['first_link'] = 'FALSE';
$config['last_link'] = 'FALSE';
$config['next_tag_open'] = '<li>';
$config['next_tag_close'] = '</li>';
$config['prev_tag_open'] = '<li>';
$config['prev_tag_close'] = '</li>';
$config['cur_tag_open'] = '<li><a href="#">';
$config['cur_tag_close'] = '</a></li>';
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';                   