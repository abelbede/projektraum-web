<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Undefined variable: article C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
ERROR - 2016-11-01 00:05:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\cms\application\helpers\cms_helper.php 51
