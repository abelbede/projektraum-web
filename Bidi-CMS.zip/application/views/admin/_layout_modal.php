<?php $this->load->view('admin/components/page_head'); ?>

<body style="background: #555555">
<div class="modal show" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
<!--      <div class="modal-header">
       
        <h4 class="modal-title">Page title</h4>
      </div>
      <div class="modal-body">
        <p>Was für ein Körper&hellip;</p>
      </div>-->
<?php $this->load->view($subview); //Subview is set in controller ?>
      <div class="modal-footer">
          &copy; <?php echo $meta_title ?>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->    
    
<?php $this->load->view('admin/components/page_tale'); ?>