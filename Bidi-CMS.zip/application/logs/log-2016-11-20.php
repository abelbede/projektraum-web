<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
ERROR - 2016-11-20 23:30:22 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/article/3/katharina
ERROR - 2016-11-20 23:38:02 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/article/3/katharina
ERROR - 2016-11-20 23:39:51 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/ggg
ERROR - 2016-11-20 23:41:39 --> 404 Page Not Found: http://127.0.0.1/cms/index.php/article/2/Table-with-CSS
ERROR - 2016-11-20 23:53:22 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\cms\application\controllers\Article.php 22
ERROR - 2016-11-20 23:57:06 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\cms\application\controllers\Article.php 28
ERROR - 2016-11-20 23:57:35 --> 404 Page Not Found: article/60/Giacomo-Casanova
