<?php
class Frontend_Controller extends MY_Controller{
    
    public function __construct(){
        parent::__construct();
        
        //Load stuff for menu
        $this->load->model('page_m');       
       $this->load->model('article_m');
        $this->data['recent_news'] = $this->article_m->get_recent();
        
        //Fetch navigation
        $this->data['menu'] = $this->page_m->get_nested();
        //Get the archive-link in every view
        $this->data['news_archive_link'] = $this->page_m->get_archive_link();
        $this->data['meta_title'] = config_item('site_name');
    }
    
}